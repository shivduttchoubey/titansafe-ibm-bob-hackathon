# THREAT BRIEF TB-CASE-CYBERATT-2026
**Generated:** 2026-09-28T14:31:52+05:30 IST / 2026-09-28T09:01:52+00:00 UTC  
**Overall severity:** HIGH  |  **Evidence anchor (Merkle root):** `3121fa3011a8bd4ca6bf0dd3...`

> Built from the privacy-preserving LEA view only. No raw user data, identities or contact details were available to this tool.

## CL-01 - INCITEMENT [HIGH]
- **Confidence:** 0.9  |  **CIB score:** 0.76  |  **Accounts (ZK-proven):** at least 5
- **Active window:** 2027-06-10T10:37:44.551568+00:00 -> 2027-06-10T11:07:51.869075+00:00 (30.1 min)
- **Why flagged:** active window 30 min; 100% of accounts <30 days old at first post; text/target similarity 0.58; key phrases: attack
- **Flags:** none

**Indicative legal provisions (IPC -> BNS)**

- Promoting enmity between groups on grounds of religion, race, place of birth, language etc.: IPC 153A -> **BNS 196**
- Statements creating or promoting enmity, hatred or ill-will between classes: IPC 505(2) -> **BNS 353(2)**
- Abetment (instigation) of an offence, if the act abetted is committed: IPC 107/109 -> **BNS 45/49**
- Criminal conspiracy (coordinated, pre-planned campaign): IPC 120B -> **BNS 61(2)**
- Unlawful assembly / rioting (if the call to gather materialises): IPC 141/147 -> **BNS 189/191**

**Recommended escalation**

1. IMMEDIATE (0-1h): alert District SP / Control Room and local law-and-order units for the named location and time
2. Send takedown notice to platform under IT Act s.79(3)(b); request preservation of the flagged cluster
3. Request T1 evidence for the cluster (redacted posts + pseudonyms) if not already held
4. Seek magistrate order, then request T2 identity reveal for ORGANISERS only (earliest-active pseudonyms)
5. Coordinate with State Cyber Cell; prepare FIR under the mapped BNS sections

## CL-02 - ORGANIZED MISINFORMATION [MEDIUM]
- **Confidence:** 0.93  |  **CIB score:** 0.77  |  **Accounts (ZK-proven):** at least 10
- **Active window:** 2027-06-10T10:30:59.988311+00:00 -> 2027-06-10T11:09:50.627761+00:00 (38.8 min)
- **Why flagged:** active window 39 min; 100% of accounts <30 days old at first post; text/target similarity 0.63; key phrases: breaking
- **Flags:** none

**Indicative legal provisions (IPC -> BNS)**

- Statement likely to cause fear or alarm to the public: IPC 505(1)(b) -> **BNS 353(1)(b)**
- Imputations/assertions prejudicial to national integration (if targeting a community): IPC 153B -> **BNS 197**
- Statements promoting enmity between classes (if communal framing): IPC 505(2) -> **BNS 353(2)**
- Criminal conspiracy (coordinated amplification): IPC 120B -> **BNS 61(2)**

**Recommended escalation**

1. Verify the claim with the responsible authority (e.g. water board / district admin) and publish a rebuttal
2. Issue takedown / labelling request to platform; monitor spread for community-directed framing
3. Request T1 evidence to assess origin pattern; T2 only if the claim escalates to incitement

## Process references

- BNSS s.94 (CrPC s.91): notice for production of documents/records
- IT Act s.79(3)(b) + IT Rules 2021 r.3(1)(d): takedown notice to intermediary
- IT Act s.69A: blocking order via MeitY (only if content is severe and persistent)

## Privacy ledger (what this investigation has seen)

- Pseudonyms seen: 18 of 1010 users in dataset
- Identities revealed: 3 (0.3%)
- Never disclosed: phone number, e-mail, IP / device data, private messages, contacts / graph, posts outside the flagged clusters

_Legal mapping is indicative decision support; confirm with the investigating officer and public prosecutor._