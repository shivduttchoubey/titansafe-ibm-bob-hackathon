# THREAT BRIEF TB-CASE-COMMUNAL-2026
**Generated:** 2026-09-28T14:31:42+05:30 IST / 2026-09-28T09:01:42+00:00 UTC  
**Overall severity:** CRITICAL  |  **Evidence anchor (Merkle root):** `074d34d080e5954b25f656ce...`

> Built from the privacy-preserving LEA view only. No raw user data, identities or contact details were available to this tool.

## CL-01 - INCITEMENT [CRITICAL]
- **Confidence:** 1.0  |  **CIB score:** 0.87  |  **Accounts (ZK-proven):** at least 20
- **Active window:** 2027-01-05T16:00:26.196007+00:00 -> 2027-01-05T16:08:46.378318+00:00 (8.3 min)
- **Why flagged:** active window 8 min; 100% of accounts <30 days old at first post; text/target similarity 0.57; key phrases: sticks, finish this, come to, attack
- **Flags:** imminent_offline_action

**Indicative legal provisions (IPC -> BNS)**

- Promoting enmity between groups on grounds of religion, race, place of birth, language etc.: IPC 153A -> **BNS 196**
- Statements creating or promoting enmity, hatred or ill-will between classes: IPC 505(2) -> **BNS 353(2)**
- Abetment (instigation) of an offence, if the act abetted is committed: IPC 107/109 -> **BNS 45/49**
- Criminal conspiracy (coordinated, pre-planned campaign): IPC 120B -> **BNS 61(2)**
- Unlawful assembly / rioting (if the call to gather materialises): IPC 141/147 -> **BNS 189/191**

**Recommended escalation**

1. IMMEDIATE (0-1h): alert District SP / Control Room and local law-and-order units for the named location and time
2. Send takedown notice to platform under IT Act s.79(3)(b); request preservation of the flagged cluster
3. Request T1 evidence for the cluster (redacted posts + pseudonyms) if not already held
4. Seek magistrate order, then request T2 identity reveal for ORGANISERS only (earliest-active pseudonyms)
5. Coordinate with State Cyber Cell; prepare FIR under the mapped BNS sections

## CL-02 - INCITEMENT [CRITICAL]
- **Confidence:** 1.0  |  **CIB score:** 0.85  |  **Accounts (ZK-proven):** at least 20
- **Active window:** 2027-01-05T16:00:38.251633+00:00 -> 2027-01-05T16:09:30.205651+00:00 (8.9 min)
- **Why flagged:** active window 9 min; 100% of accounts <30 days old at first post; text/target similarity 0.50; key phrases: gather, attack, weapons
- **Flags:** imminent_offline_action

**Indicative legal provisions (IPC -> BNS)**

- Promoting enmity between groups on grounds of religion, race, place of birth, language etc.: IPC 153A -> **BNS 196**
- Statements creating or promoting enmity, hatred or ill-will between classes: IPC 505(2) -> **BNS 353(2)**
- Abetment (instigation) of an offence, if the act abetted is committed: IPC 107/109 -> **BNS 45/49**
- Criminal conspiracy (coordinated, pre-planned campaign): IPC 120B -> **BNS 61(2)**
- Unlawful assembly / rioting (if the call to gather materialises): IPC 141/147 -> **BNS 189/191**

**Recommended escalation**

1. IMMEDIATE (0-1h): alert District SP / Control Room and local law-and-order units for the named location and time
2. Send takedown notice to platform under IT Act s.79(3)(b); request preservation of the flagged cluster
3. Request T1 evidence for the cluster (redacted posts + pseudonyms) if not already held
4. Seek magistrate order, then request T2 identity reveal for ORGANISERS only (earliest-active pseudonyms)
5. Coordinate with State Cyber Cell; prepare FIR under the mapped BNS sections

## CL-03 - INCITEMENT [CRITICAL]
- **Confidence:** 1.0  |  **CIB score:** 0.83  |  **Accounts (ZK-proven):** at least 40
- **Active window:** 2027-01-05T16:00:58.736612+00:00 -> 2027-01-05T16:08:52.339014+00:00 (7.9 min)
- **Why flagged:** active window 8 min; 100% of accounts <30 days old at first post; text/target similarity 0.40; key phrases: bring sticks, sticks, attack, gather
- **Flags:** imminent_offline_action

**Indicative legal provisions (IPC -> BNS)**

- Promoting enmity between groups on grounds of religion, race, place of birth, language etc.: IPC 153A -> **BNS 196**
- Statements creating or promoting enmity, hatred or ill-will between classes: IPC 505(2) -> **BNS 353(2)**
- Abetment (instigation) of an offence, if the act abetted is committed: IPC 107/109 -> **BNS 45/49**
- Criminal conspiracy (coordinated, pre-planned campaign): IPC 120B -> **BNS 61(2)**
- Unlawful assembly / rioting (if the call to gather materialises): IPC 141/147 -> **BNS 189/191**

**Recommended escalation**

1. IMMEDIATE (0-1h): alert District SP / Control Room and local law-and-order units for the named location and time
2. Send takedown notice to platform under IT Act s.79(3)(b); request preservation of the flagged cluster
3. Request T1 evidence for the cluster (redacted posts + pseudonyms) if not already held
4. Seek magistrate order, then request T2 identity reveal for ORGANISERS only (earliest-active pseudonyms)
5. Coordinate with State Cyber Cell; prepare FIR under the mapped BNS sections

## CL-04 - ORGANIZED MISINFORMATION [MEDIUM]
- **Confidence:** 0.58  |  **CIB score:** 0.88  |  **Accounts (ZK-proven):** at least 20
- **Active window:** 2027-01-05T17:02:32.091542+00:00 -> 2027-01-05T17:23:55.688209+00:00 (21.4 min)
- **Why flagged:** active window 21 min; 100% of accounts <30 days old at first post; text/target similarity 0.74; key phrases: breaking, outsiders
- **Flags:** none

**Indicative legal provisions (IPC -> BNS)**

- Statement likely to cause fear or alarm to the public: IPC 505(1)(b) -> **BNS 353(1)(b)**
- Imputations/assertions prejudicial to national integration (if targeting a community): IPC 153B -> **BNS 197**
- Statements promoting enmity between classes (if communal framing): IPC 505(2) -> **BNS 353(2)**
- Criminal conspiracy (coordinated amplification): IPC 120B -> **BNS 61(2)**

**Recommended escalation**

1. Verify the claim with the responsible authority (e.g. water board / district admin) and publish a rebuttal
2. Issue takedown / labelling request to platform; monitor spread for community-directed framing
3. Request T1 evidence to assess origin pattern; T2 only if the claim escalates to incitement

## CL-05 - ORGANIZED MISINFORMATION [MEDIUM]
- **Confidence:** 1.0  |  **CIB score:** 0.84  |  **Accounts (ZK-proven):** at least 10
- **Active window:** 2027-01-05T17:00:22.541141+00:00 -> 2027-01-05T17:23:07.519468+00:00 (22.7 min)
- **Why flagged:** active window 23 min; 100% of accounts <30 days old at first post; text/target similarity 0.60; key phrases: forward to all, urgent
- **Flags:** none

**Indicative legal provisions (IPC -> BNS)**

- Statement likely to cause fear or alarm to the public: IPC 505(1)(b) -> **BNS 353(1)(b)**
- Imputations/assertions prejudicial to national integration (if targeting a community): IPC 153B -> **BNS 197**
- Statements promoting enmity between classes (if communal framing): IPC 505(2) -> **BNS 353(2)**
- Criminal conspiracy (coordinated amplification): IPC 120B -> **BNS 61(2)**

**Recommended escalation**

1. Verify the claim with the responsible authority (e.g. water board / district admin) and publish a rebuttal
2. Issue takedown / labelling request to platform; monitor spread for community-directed framing
3. Request T1 evidence to assess origin pattern; T2 only if the claim escalates to incitement

## Process references

- BNSS s.94 (CrPC s.91): notice for production of documents/records
- IT Act s.79(3)(b) + IT Rules 2021 r.3(1)(d): takedown notice to intermediary
- IT Act s.69A: blocking order via MeitY (only if content is severe and persistent)

## Privacy ledger (what this investigation has seen)

- Pseudonyms seen: 136 of 1020 users in dataset
- Identities revealed: 3 (0.29%)
- Never disclosed: phone number, e-mail, IP / device data, private messages, contacts / graph, posts outside the flagged clusters

_Legal mapping is indicative decision support; confirm with the investigating officer and public prosecutor._