# Presentation

Place the slide deck here as `slides.pdf` (or `slides.pptx`).

## Suggested slide structure

| Slide | Title | Content |
|---|---|---|
| 1 | TitanSafe | Project title, team name, track |
| 2 | The Problem | DPDP tension: bulk disclosure vs. no disclosure |
| 3 | Our Solution | Three-tier privacy-preserving disclosure model |
| 4 | Architecture | Mermaid diagram from docs/architecture.md |
| 5 | Cryptographic Guarantees | ZK proofs, Merkle anchoring, per-case pseudonyms |
| 6 | CIB Detection | Signal weights, explainability, false-positive traps |
| 7 | Dashboard Demo | Screenshots from demo/screenshots/ |
| 8 | Mock Datasets | Table of 4 datasets and what they test |
| 9 | Verification | `TitanSafe verify` — LEA-side independent proof check |
| 10 | Limitations & Next Steps | Honest gaps + production path |
| 11 | What We're Most Proud Of | The ZK + Merkle integrity chain |

## File naming

Name your slide file: `TitanSafe-presentation.pdf`
