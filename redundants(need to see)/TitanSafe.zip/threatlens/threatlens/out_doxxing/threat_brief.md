# THREAT BRIEF TB-CASE-JOURNALI-2026
**Generated:** 2026-09-28T14:31:49+05:30 IST / 2026-09-28T09:01:49+00:00 UTC  
**Overall severity:** MEDIUM  |  **Evidence anchor (Merkle root):** `b749aab392bd505391690bab...`

> Built from the privacy-preserving LEA view only. No raw user data, identities or contact details were available to this tool.

## CL-01 - TARGETED HARASSMENT [MEDIUM]
- **Confidence:** 1.0  |  **CIB score:** 0.98  |  **Accounts (ZK-proven):** at least 10
- **Active window:** 2026-11-18T14:01:27.452017+00:00 -> 2026-11-18T14:10:35.325005+00:00 (9.1 min)
- **Why flagged:** active window 9 min; 100% of accounts <30 days old at first post; text/target similarity 1.00; key phrases: deserves what
- **Flags:** none  |  **Target:** @mehak_writes

**Indicative legal provisions (IPC -> BNS)**

- Criminal intimidation: IPC 506 -> **BNS 351**
- Stalking, including monitoring of online activity: IPC 354D -> **BNS 78**
- Word/gesture intended to insult the modesty of a woman (if victim is a woman): IPC 509 -> **BNS 79**
- Defamation: IPC 499/500 -> **BNS 356**
- Criminal conspiracy (coordinated brigading): IPC 120B -> **BNS 61(2)**

**Recommended escalation**

1. Contact the targeted person; advise on safety and preservation of screenshots
2. Request platform takedown of doxxed content; register complaint / FIR (BNS s.351, s.78)
3. Request T1 evidence, then T2 for the smallest set of pseudonyms that drive the campaign
4. Consider protective measures (beat patrol) if a home address was exposed

## CL-02 - TARGETED HARASSMENT [MEDIUM]
- **Confidence:** 1.0  |  **CIB score:** 0.97  |  **Accounts (ZK-proven):** at least 20
- **Active window:** 2026-11-18T14:00:25.875997+00:00 -> 2026-11-18T14:11:53.963595+00:00 (11.5 min)
- **Why flagged:** active window 11 min; 100% of accounts <30 days old at first post; text/target similarity 1.00; key phrases: watch your back, your family, stop writing
- **Flags:** none  |  **Target:** @mehak_writes

**Indicative legal provisions (IPC -> BNS)**

- Criminal intimidation: IPC 506 -> **BNS 351**
- Stalking, including monitoring of online activity: IPC 354D -> **BNS 78**
- Word/gesture intended to insult the modesty of a woman (if victim is a woman): IPC 509 -> **BNS 79**
- Defamation: IPC 499/500 -> **BNS 356**
- Criminal conspiracy (coordinated brigading): IPC 120B -> **BNS 61(2)**

**Recommended escalation**

1. Contact the targeted person; advise on safety and preservation of screenshots
2. Request platform takedown of doxxed content; register complaint / FIR (BNS s.351, s.78)
3. Request T1 evidence, then T2 for the smallest set of pseudonyms that drive the campaign
4. Consider protective measures (beat patrol) if a home address was exposed

## Process references

- BNSS s.94 (CrPC s.91): notice for production of documents/records
- IT Act s.79(3)(b) + IT Rules 2021 r.3(1)(d): takedown notice to intermediary
- IT Act s.69A: blocking order via MeitY (only if content is severe and persistent)

## Privacy ledger (what this investigation has seen)

- Pseudonyms seen: 38 of 1015 users in dataset
- Identities revealed: 3 (0.3%)
- Never disclosed: phone number, e-mail, IP / device data, private messages, contacts / graph, posts outside the flagged clusters

_Legal mapping is indicative decision support; confirm with the investigating officer and public prosecutor._